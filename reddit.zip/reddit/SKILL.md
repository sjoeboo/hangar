---
name: reddit
description: Browse, search, post, and moderate Reddit from Claude Code. Use when the user wants to read subreddit posts, search Reddit, get comments, submit posts, reply to threads, or perform subreddit moderation. Read-only actions work without auth; posting/moderation requires Reddit OAuth setup. Triggers on any Reddit-related request.
---

# Reddit

Browse, search, post, and moderate subreddits via `scripts/reddit.mjs`.

Read-only actions (posts, search, comments) use Reddit's public JSON API with no auth required.
Write actions (submit, reply, moderation) require OAuth setup.

## Setup (only for posting/moderation)

Skip this section for read-only usage. No setup needed to browse or search.

1. Go to https://www.reddit.com/prefs/apps
2. Click "create another app..." and select "script" type
3. Set redirect URI to `http://localhost:8080`
4. Note the client ID (under app name) and client secret
5. Set environment variables:
   ```bash
   export REDDIT_CLIENT_ID="your_client_id"
   export REDDIT_CLIENT_SECRET="your_client_secret"
   ```
6. Run the login command once:
   ```bash
   node {baseDir}/scripts/reddit.mjs login
   ```
   This opens a browser for OAuth authorization. Token is saved to `~/.reddit-token.json` and auto-refreshes.

## Commands

All commands follow the pattern: `node {baseDir}/scripts/reddit.mjs <command> [args] [--flags]`

### Read Posts (no auth)

```bash
# Hot posts (default)
node {baseDir}/scripts/reddit.mjs posts <subreddit>

# Sort: hot, new, top, controversial
node {baseDir}/scripts/reddit.mjs posts <subreddit> --sort top --time week

# Limit results (default 25)
node {baseDir}/scripts/reddit.mjs posts <subreddit> --limit 5
```

Time options for top/controversial: `day`, `week`, `month`, `year`, `all`

### Search Posts (no auth)

```bash
# Search within a subreddit
node {baseDir}/scripts/reddit.mjs search <subreddit> "query"

# Search all of Reddit
node {baseDir}/scripts/reddit.mjs search all "query"

# With sort and time filters
node {baseDir}/scripts/reddit.mjs search <subreddit> "query" --sort top --time month
```

### Get Comments (no auth)

```bash
# By post ID
node {baseDir}/scripts/reddit.mjs comments <post_id>

# By full URL
node {baseDir}/scripts/reddit.mjs comments "https://reddit.com/r/subreddit/comments/abc123/..."
```

### Submit a Post (requires auth)

```bash
# Text post
node {baseDir}/scripts/reddit.mjs submit <subreddit> --title "Title" --text "Body text"

# Link post
node {baseDir}/scripts/reddit.mjs submit <subreddit> --title "Title" --url "https://example.com"
```

### Reply (requires auth)

```bash
node {baseDir}/scripts/reddit.mjs reply <thing_id> "Your reply text"
```

Thing IDs: post IDs are prefixed `t3_`, comment IDs are `t1_`. The script auto-prefixes if needed.

### Moderation (requires auth + mod permissions)

```bash
node {baseDir}/scripts/reddit.mjs mod remove <thing_id>
node {baseDir}/scripts/reddit.mjs mod approve <thing_id>
node {baseDir}/scripts/reddit.mjs mod sticky <post_id>
node {baseDir}/scripts/reddit.mjs mod unsticky <post_id>
node {baseDir}/scripts/reddit.mjs mod lock <post_id>
node {baseDir}/scripts/reddit.mjs mod unlock <post_id>
node {baseDir}/scripts/reddit.mjs mod queue <subreddit>
```

### Identity (requires auth)

```bash
node {baseDir}/scripts/reddit.mjs whoami
```

## Output Format

All commands output JSON. Posts include: `id`, `title`, `author`, `score`, `comments`, `url`, `permalink`, `created`, `selftext`, `flair`. Comments include: `id`, `author`, `body`, `score`, `depth`, `created`.

## Rate Limits

- Unauthenticated: ~10 requests/minute
- OAuth authenticated: ~60 requests/minute
